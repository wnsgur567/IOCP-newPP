#pragma once

class SectorOwner
{

};