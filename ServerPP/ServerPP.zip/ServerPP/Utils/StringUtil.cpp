#include "StringUtil.h"

namespace Utils
{

	bool StringUtil::SetLocale()
	{
		_wsetlocale(LC_ALL, L"Korean");

		return true;
	}

	DWORD StringUtil::Convert_ansi_to_unicode_string(std::wstring& unicode, const char* ansi, const size_t ansi_size)
	{
		DWORD error = 0;
		do {
			if ((nullptr == ansi) || (0 == ansi_size)) {
				error = ERROR_INVALID_PARAMETER;
				break;
			}
			unicode.clear();
			//
			// getting required cch.
			//
			int required_cch = ::MultiByteToWideChar(
				CP_ACP,
				0,
				ansi, static_cast<int>(ansi_size),
				nullptr, 0
			);
			if (0 == required_cch) {
				error = ::GetLastError();
				break;
			}
			unicode.resize(required_cch);
			//
			// convert.
			//
			if (0 == ::MultiByteToWideChar(
				CP_ACP,
				0,
				ansi, static_cast<int>(ansi_size),
				const_cast<wchar_t*>(unicode.c_str()), static_cast<int>(unicode.size())
			)) {
				error = ::GetLastError();
				break;
			}
		} while (false);
		return error;
	}

	DWORD StringUtil::Convert_unicode_to_ansi_string(
		std::string& ansi,
		const wchar_t* unicode,
		const size_t unicode_size
	) {
		DWORD error = 0;
		do {
			if ((nullptr == unicode) || (0 == unicode_size)) {
				error = ERROR_INVALID_PARAMETER;
				break;
			}
			ansi.clear();
			//
			// getting required cch.
			//
			int required_cch = ::WideCharToMultiByte(
				CP_ACP,
				0,
				unicode, static_cast<int>(unicode_size),
				nullptr, 0,
				nullptr, nullptr
			);
			if (0 == required_cch) {
				error = ::GetLastError();
				break;
			}
			//
			// allocate.
			//
			ansi.resize(required_cch);
			//
			// convert.
			//
			if (0 == ::WideCharToMultiByte(
				CP_ACP,
				0,
				unicode, static_cast<int>(unicode_size),
				const_cast<char*>(ansi.c_str()), static_cast<int>(ansi.size()),
				nullptr, nullptr
			)) {
				error = ::GetLastError();
				break;
			}
		} while (false);
		return error;
	}

	DWORD StringUtil::Convert_unicode_to_utf8_string(
		std::string& utf8,
		const wchar_t* unicode,
		const size_t unicode_size
	) {
		DWORD error = 0;
		do {
			if ((nullptr == unicode) || (0 == unicode_size)) {
				error = ERROR_INVALID_PARAMETER;
				break;
			}
			utf8.clear();
			//
			// getting required cch.
			//
			int required_cch = ::WideCharToMultiByte(
				CP_UTF8,
				WC_ERR_INVALID_CHARS,
				unicode, static_cast<int>(unicode_size),
				nullptr, 0,
				nullptr, nullptr
			);
			if (0 == required_cch) {
				error = ::GetLastError();
				break;
			}
			//
			// allocate.
			//
			utf8.resize(required_cch);
			//
			// convert.
			//
			if (0 == ::WideCharToMultiByte(
				CP_UTF8,
				WC_ERR_INVALID_CHARS,
				unicode, static_cast<int>(unicode_size),
				const_cast<char*>(utf8.c_str()), static_cast<int>(utf8.size()),
				nullptr, nullptr
			)) {
				error = ::GetLastError();
				break;
			}
		} while (false);
		return error;
	}

	DWORD StringUtil::Convert_utf8_to_unicode_string(
		std::wstring& unicode,
		const char* utf8,
		const size_t utf8_size
	) {
		DWORD error = 0;
		do {
			if ((nullptr == utf8) || (0 == utf8_size)) {
				error = ERROR_INVALID_PARAMETER;
				break;
			}
			unicode.clear();
			//
			// getting required cch.
			//
			int required_cch = ::MultiByteToWideChar(
				CP_UTF8,
				MB_ERR_INVALID_CHARS,
				utf8, static_cast<int>(utf8_size),
				nullptr, 0
			);
			if (0 == required_cch) {
				error = ::GetLastError();
				break;
			}
			//
			// allocate.
			//
			unicode.resize(required_cch);
			//
			// convert.
			//
			if (0 == ::MultiByteToWideChar(
				CP_UTF8,
				MB_ERR_INVALID_CHARS,
				utf8, static_cast<int>(utf8_size),
				const_cast<wchar_t*>(unicode.c_str()), static_cast<int>(unicode.size())
			)) {
				error = ::GetLastError();
				break;
			}
		} while (false);
		return error;
	}

	std::string StringUtil::trim(std::string& s, const std::string& drop)
	{
		std::string r = s.erase(s.find_last_not_of(drop) + 1);
		return r.erase(0, r.find_first_not_of(drop));
	}

	std::string StringUtil::rtrim(std::string& s, const std::string& drop)
	{
		return s.erase(s.find_last_not_of(drop) + 1);
	}

	std::string StringUtil::ltrim(std::string& s, const std::string& drop)
	{
		return s.erase(0, s.find_first_not_of(drop));
	}
}
